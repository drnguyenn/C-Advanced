#include <stdio.h>
#include <stdlib.h>
#include "/home/long/Cprogramming/Cadvanced/libgra/udr_graph.h"
#include "/home/long/Cprogramming/Cadvanced/libfdr/dllist.h"

void BFS(Graph graph,int start,int stop,void (*func)(int))
{
    int i,n,output[100];
    JRB node;
    JRB visited;
    visited = make_jrb();
    jrb_traverse(node, graph)
        jrb_insert_int(visited, jval_i(node->key), new_jval_i(0));

    Dllist temp,queue;
    queue = new_dllist()
    dll_append(queue, new_jval_i(start));

    while(!dll_empty(queue))
    {
        temp = dll_first(queue);
        Jval value = temp->val;
        dll_delete_node(temp);
        //if(visited[jval_i(temp->val) - 1] != 1)
        node = jrb_find_int(visited, jval_i(value));
        if(jval_i(node->val) == 0)
        {
            if(jval_i(value) == stop)
            {
                free_dllist(queue);
                printf("True\n");
                return;
            }
            //visited[jval_i(temp->val) - 1] = 1;
            node->val = new_jval_i(1);
            n = getAdjacentVertices(graph, jval_i(value), output);
            JRB _node;
            for(i = 0; i < n; i ++)
            {
                _node = jrb_find_int(visited, output[i]);
                if(jval_i(_node->val) == 0)
                    dll_append(queue, new_jval_i(output[i]));
            }
            //
        }
    }
    free_dllist(queue);
    printf("False\n");
}

void DFS(Graph graph,int start,int stop,void (*func)(int))
{
    JRB node;
    JRB visited;
    visited = make_jrb();
    jrb_traverse(node, graph)
        jrb_insert_int(visited, jval_i(node->key), new_jval_i(0));

    Dllist stack = new_dllist();
    dll_append(stack, new_jval_i(start));

    Dllist temp;
    int n, output[100];
    int i;
    while(!dll_empty(stack))
    {
        temp = dll_last(stack);
        Jval value = temp->val;
        dll_delete_node(temp);
        node = jrb_find_int(visited, jval_i(value));
        if(jval_i(node->val) == 0)
        {
            if(jval_i(value) == stop)
            {
                free_dllist(stack);
                printf("True\n");
                return;
            }
            node->val = new_jval_i(1);
            n = getAdjacentVertices(graph, jval_i(value), output);
            JRB _node;
            for(i = 0; i < n; i ++)
            {
                _node = jrb_find_int(visited, output[i]);
                if(jval_i(_node->val) == 0)
                    dll_append(stack, new_jval_i(output[i]));
            }
        }
    }
    free_dllist(stack);
    printf("False\n");
}

void printVertex(int v)
{
    printf("%3d",v);
}

int main()
{
    Graph g = createGraph();
    addEdge(g, 0, 1);
    addEdge(g, 1, 2);
    addEdge(g, 1, 3);
    addEdge(g, 2, 3);
    addEdge(g, 2, 4);
    addEdge(g, 4, 5);
    printf("\nBFS: start from node 1 to 5: ");
    BFS(g, 1, 4, printVertex);
    printf("\nBFS: start from node 1 to all: ");
    BFS(g, 1, -1, printVertex);
    return 0;
}


