#include <stdio.h>
#include <stdlib.h>
#include "libfdr/jrb.h"
#include "libfdr/jval.h"
#include "libfdr/dllist.h"
#include "graph_jrb.h"

void DFS(Graph graph, int start, int stop)
{
    JRB node;
    JRB visited;
    visited = make_jrb();
    jrb_traverse(node, graph)
        jrb_insert_int(visited, jval_i(node->key), new_jval_i(0)); // visited chua' key int, jval value

    Dllist stack = new_dllist();
    dll_append(stack, new_jval_i(start)); // stack chua' ddlist // ddlist -> val = jval // jval-> i = key

    //
    Dllist temp;
    int n, output[100];
    int i;
    while(!dll_empty(stack))
    {
        temp = dll_last(stack);
        Jval value = temp->val;
        dll_delete_node(temp);
        //if(visited[jval_i(temp->val) - 1] != 1)
        node = jrb_find_int(visited, jval_i(value));
        if(jval_i(node->val) == 0)
        {
            if(jval_i(value) == stop)
            {
                free_dllist(stack);
                printf("True\n");
                return;
            }
            //visited[jval_i(temp->val) - 1] = 1;
            node->val = new_jval_i(1);
            n = getAdjacentVertices(graph, jval_i(value), output);
            JRB _node;
            for(i = 0; i < n; i ++)
            {
                _node = jrb_find_int(visited, output[i]);
                if(jval_i(_node->val) == 0)
                    dll_append(stack, new_jval_i(output[i]));
            }
            //
        }
    }
    free_dllist(stack);
    printf("False\n");
}



int main()
{
    Graph graph = createGraph();
    addEdge(graph, 0, 1);
    addEdge(graph, 0, 2);
    addEdge(graph, 1, 2);
    addEdge(graph, 2, 4);
    DFS(graph, 0, 4);
    dropGraph(graph);
    return 0;
}


