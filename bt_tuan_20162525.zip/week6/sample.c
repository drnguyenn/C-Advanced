#include <stdio.h>
#include <stdlib.h>
#include "/home/long/Cprogramming/Cadvanced/libgra/udr_graph.h"

int main()
{
    int i, n, output[10];
    Graph graph = createGraph();
    addEdge(graph, 0, 1);
    addEdge(graph, 0, 2);
    addEdge(graph, 1, 2);
    addEdge(graph, 1, 3);
    addEdge(graph, 2, 3);
    addEdge(graph, 2, 4);
    n = getAdjacentVertices(graph, 2, output);
    if(n == 0)
        printf("\nNo adjacent vertices of node 2 !\n");
    else
    {
        for(i = 0; i < n; i ++) printf("%d ", output[i]);
        printf("\n");
    }
    dropGraph(graph);
    return 0;
}
