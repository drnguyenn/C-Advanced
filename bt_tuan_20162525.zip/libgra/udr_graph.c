#include <stdio.h>
#include <stdlib.h>
#include "udr_graph.h"

Graph createGraph()
{
    return make_jrb();
}

int adjacent(Graph graph, int v1, int v2)
{
    JRB node, tree;
    node = jrb_find_int(graph, v1);
    if(node == NULL) return 0;
    tree = (JRB) jval_v(node->val);
    if(jrb_find_int(tree, v2) == NULL) return 0;
    else return 1;
}

int getAdjacentVertices(Graph graph, int v, int *output)
{
    JRB tree, node;
    int total;
    node = jrb_find_int(graph, v);
    if(node == NULL) return 0;
    tree = (JRB)jval_v(node->val);
    total = 0;
    jrb_traverse(node, tree)
    {
        output[total] = jval_i(node->key);
        total++;
    }
    return total;
}

void addEdge(Graph graph, int v1, int v2)
{
    JRB node, tree;
    if(!adjacent(graph, v1, v2))
    {
        node = jrb_find_int(graph, v1);
        if(node == NULL)
        {
            tree = make_jrb();
            jrb_insert_int(graph, v1, new_jval_v(tree));
        }
        else
            tree = (JRB)jval_v(node->val);
        jrb_insert_int(tree, v2, new_jval_i(1));
    }
    if(!adjacent(graph, v2, v1))
    {
        node = jrb_find_int(graph, v2);
        if(node == NULL)
        {
            tree = make_jrb();
            jrb_insert_int(graph, v2, new_jval_v(tree));
        }
        else
            tree = (JRB)jval_v(node->val);
        jrb_insert_int(tree, v1, new_jval_i(1));
    }
}

void dropGraph(Graph graph)
{
    JRB node;
    jrb_traverse(node, graph)
        jrb_free_tree((JRB)jval_v(node->val));
    jrb_free_tree(graph);
}
